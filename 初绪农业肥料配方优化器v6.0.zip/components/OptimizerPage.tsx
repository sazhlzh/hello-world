
import React, { useState, useCallback, useMemo } from 'react';
import { TargetElement, RawMaterial, OptimizationResult } from '../types';
import { DEFAULT_TARGET_ELEMENTS, DEFAULT_RAW_MATERIALS } from '../constants';
import { solveOptimization } from '../services/optimizer';
import { PlusIcon, TrashIcon } from './Icons';

// Helper to generate unique IDs
let elementIdCounter = DEFAULT_TARGET_ELEMENTS.length;
let materialIdCounter = DEFAULT_RAW_MATERIALS.length;

const OptimizerPage: React.FC = () => {
    const [totalProduction, setTotalProduction] = useState('1');
    const [targetElements, setTargetElements] = useState<TargetElement[]>(
        () => DEFAULT_TARGET_ELEMENTS.map((el, i) => ({ ...el, id: i }))
    );
    const [rawMaterials, setRawMaterials] = useState<RawMaterial[]>(
        () => DEFAULT_RAW_MATERIALS.map((mat, i) => {
            const allElements = {};
            DEFAULT_TARGET_ELEMENTS.forEach(el => {
                allElements[el.name] = mat.elements[el.name] || '0';
            });
            return { ...mat, id: i, elements: allElements, price: '' };
        })
    );
    const [result, setResult] = useState<OptimizationResult | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const elementNames = useMemo(() => targetElements.map(e => e.name), [targetElements]);

    const handleAddElement = () => {
        const newElement: TargetElement = {
            id: ++elementIdCounter,
            name: '',
            percentage: '0'
        };
        setTargetElements(prev => [...prev, newElement]);
        // Also add this new element to all raw materials
        setRawMaterials(prev => prev.map(mat => ({
            ...mat,
            elements: { ...mat.elements, ['']: '0' }
        })));
    };

    const handleElementChange = <K extends keyof TargetElement>(index: number, field: K, value: TargetElement[K]) => {
        const newElements = [...targetElements];
        const oldName = newElements[index].name;
        newElements[index][field] = value;
        setTargetElements(newElements);
        
        if (field === 'name') {
            const newName = value as string;
            setRawMaterials(prev => prev.map(mat => {
                const newElems = {...mat.elements};
                if (oldName in newElems) {
                    newElems[newName] = newElems[oldName];
                    delete newElems[oldName];
                }
                return {...mat, elements: newElems };
            }));
        }
    };
    
    const handleDeleteElement = (id: number) => {
        const elementToDelete = targetElements.find(el => el.id === id);
        if (!elementToDelete) return;
        
        setTargetElements(prev => prev.filter(el => el.id !== id));
        setRawMaterials(prev => prev.map(mat => {
            const newElements = { ...mat.elements };
            delete newElements[elementToDelete.name];
            return { ...mat, elements: newElements };
        }));
    };

    const handleAddMaterial = () => {
        const newMaterial: RawMaterial = {
            id: ++materialIdCounter,
            name: '',
            elements: elementNames.reduce((acc, name) => ({ ...acc, [name]: '0' }), {}),
            price: ''
        };
        setRawMaterials(prev => [...prev, newMaterial]);
    };
    
    const handleMaterialChange = (index: number, field: 'name' | 'price' | 'elements', value: string, elementKey?: string) => {
        const newMaterials = [...rawMaterials];
        if (field === 'elements' && elementKey) {
            newMaterials[index].elements[elementKey] = value;
        } else if (field !== 'elements') {
             newMaterials[index][field] = value;
        }
        setRawMaterials(newMaterials);
    };

    const handleDeleteMaterial = (id: number) => {
        setRawMaterials(prev => prev.filter(mat => mat.id !== id));
    };

    const handleCalculate = useCallback(() => {
        setIsLoading(true);
        setError(null);
        setResult(null);

        // Validation
        const production = parseFloat(totalProduction);
        if (isNaN(production) || production <= 0) {
            setError('总产量必须是大于0的数字。');
            setIsLoading(false);
            return;
        }

        try {
            // Validate and parse target elements
            const parsedTargets = targetElements.map(el => {
                const percentage = parseFloat(el.percentage);
                if (!el.name.trim()) throw new Error('元素名称不能为空。');
                if (isNaN(percentage) || percentage < 0) throw new Error(`元素 "${el.name}" 的比例必须是有效的数字。`);
                return { ...el, percentage: percentage };
            });

            // Validate and parse raw materials
            const parsedMaterials = rawMaterials.map(mat => {
                const price = parseFloat(mat.price);
                if (!mat.name.trim() && !isNaN(price) && price > 0) throw new Error('有价格的原料必须有名称。');
                if (isNaN(price) && mat.name.trim()) {
                    // This allows unused materials to have empty price
                } else if (isNaN(price) || price < 0) {
                     throw new Error(`原料 "${mat.name}" 的价格必须是有效的数字。`);
                }
                
                const parsedElements = {};
                for (const elName of elementNames) {
                    const content = parseFloat(mat.elements[elName]);
                    if (isNaN(content) || content < 0) throw new Error(`原料 "${mat.name}" 的元素 "${elName}" 含量必须是有效的数字。`);
                    parsedElements[elName] = content;
                }
                return { ...mat, elements: parsedElements, price: isNaN(price) ? 0 : price };
            }).filter(mat => mat.price > 0);

            if (parsedMaterials.length === 0) {
                throw new Error("请输入至少一种原料的价格以进行计算。");
            }
            
            // Run solver
            setTimeout(() => {
                 try {
                    const solution = solveOptimization(production, parsedTargets, parsedMaterials);
                    setResult(solution);
                } catch (e) {
                    setError(e instanceof Error ? e.message : String(e));
                } finally {
                    setIsLoading(false);
                }
            }, 50);


        } catch (e) {
            setError(e instanceof Error ? e.message : String(e));
            setIsLoading(false);
        }
    }, [totalProduction, targetElements, rawMaterials, elementNames]);

    const handleReset = () => {
        setTotalProduction('1');
        setTargetElements(DEFAULT_TARGET_ELEMENTS.map((el, i) => ({ ...el, id: i })));
        setRawMaterials(DEFAULT_RAW_MATERIALS.map((mat, i) => {
            const allElements = {};
            DEFAULT_TARGET_ELEMENTS.forEach(el => {
                allElements[el.name] = mat.elements[el.name] || '0';
            });
            return { ...mat, id: i, elements: allElements, price: '' };
        }));
        setResult(null);
        setError(null);
        setIsLoading(false);
    };

    return (
        <div className="space-y-6">
            {/* Section 1: Target Elements */}
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-xl font-bold text-gray-800 mb-4">1. 目标元素配置</h2>
                <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700">总产量 (吨)</label>
                    <input
                        type="number"
                        value={totalProduction}
                        onChange={e => setTotalProduction(e.target.value)}
                        className="mt-1 w-full md:w-1/3 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-yellow-500 focus:border-yellow-500"
                    />
                </div>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">元素名称</th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">比例 (%)</th>
                                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {targetElements.map((el, index) => (
                                <tr key={el.id}>
                                    <td className="px-4 py-2 whitespace-nowrap">
                                        <input type="text" value={el.name} onChange={e => handleElementChange(index, 'name', e.target.value)} className="w-full bg-transparent border-b border-gray-200 focus:outline-none focus:border-yellow-500"/>
                                    </td>
                                    <td className="px-4 py-2 whitespace-nowrap">
                                        <input type="number" value={el.percentage} onChange={e => handleElementChange(index, 'percentage', e.target.value)} className="w-24 bg-transparent border-b border-gray-200 focus:outline-none focus:border-yellow-500"/>
                                    </td>
                                    <td className="px-4 py-2 whitespace-nowrap text-right">
                                        <button onClick={() => handleDeleteElement(el.id)} className="text-red-500 hover:text-red-700"><TrashIcon className="w-5 h-5"/></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <button onClick={handleAddElement} className="mt-4 flex items-center space-x-2 text-sm text-green-600 hover:text-green-800 font-semibold">
                    <PlusIcon className="w-5 h-5"/>
                    <span>添加元素</span>
                </button>
            </div>

            {/* Section 2: Raw Materials */}
            <div className="bg-white p-6 rounded-lg shadow-md">
                 <h2 className="text-xl font-bold text-gray-800 mb-4">2. 原料配置 (含量%及价格元/吨)</h2>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider sticky left-0 bg-gray-50 z-10">原料名称</th>
                                {elementNames.map(name => (
                                    <th key={name} className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{name.split('(')[0]}%</th>
                                ))}
                                <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">价格(元/吨)</th>
                                <th className="px-2 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                             {rawMaterials.map((mat, index) => (
                                <tr key={mat.id}>
                                    <td className="px-2 py-2 whitespace-nowrap sticky left-0 bg-white">
                                         <input type="text" value={mat.name} onChange={e => handleMaterialChange(index, 'name', e.target.value)} className="w-28 bg-transparent border-b border-gray-200 focus:outline-none focus:border-yellow-500"/>
                                    </td>
                                    {elementNames.map(elName => (
                                        <td key={elName} className="px-2 py-2 whitespace-nowrap">
                                            <input type="number" value={mat.elements[elName] || '0'} onChange={e => handleMaterialChange(index, 'elements', e.target.value, elName)} className="w-16 bg-transparent border-b border-gray-200 focus:outline-none focus:border-yellow-500"/>
                                        </td>
                                    ))}
                                    <td className="px-2 py-2 whitespace-nowrap">
                                        <input type="number" value={mat.price} onChange={e => handleMaterialChange(index, 'price', e.target.value)} className="w-24 bg-transparent border-b border-gray-200 focus:outline-none focus:border-yellow-500"/>
                                    </td>
                                    <td className="px-2 py-2 whitespace-nowrap text-right">
                                        <button onClick={() => handleDeleteMaterial(mat.id)} className="text-red-500 hover:text-red-700"><TrashIcon className="w-5 h-5"/></button>
                                    </td>
                                </tr>
                             ))}
                        </tbody>
                    </table>
                 </div>
                 <button onClick={handleAddMaterial} className="mt-4 flex items-center space-x-2 text-sm text-green-600 hover:text-green-800 font-semibold">
                    <PlusIcon className="w-5 h-5"/>
                    <span>添加原料</span>
                </button>
            </div>
            
            {/* Section 3: Calculation & Results */}
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-xl font-bold text-gray-800 mb-4">3. 计算与结果</h2>
                <div className="flex space-x-4">
                    <button onClick={handleCalculate} disabled={isLoading} className="w-full bg-yellow-400 text-gray-800 font-bold py-3 px-4 rounded-lg hover:bg-yellow-500 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center">
                        {isLoading ? (
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                        ) : '开始计算'}
                    </button>
                    <button onClick={handleReset} className="w-full bg-gray-300 text-gray-800 font-bold py-3 px-4 rounded-lg hover:bg-gray-400 transition-colors">重置</button>
                </div>
                {error && <div className="mt-4 p-4 bg-red-100 text-red-700 rounded-md"><strong>错误:</strong> {error.replace("could not convert string to float:", "输入值无效，请检查所有输入框是否都填入了正确的数字，不能留空。")}</div>}
                {result && (
                    <div className="mt-6 space-y-4">
                        {result.feasible ? (
                            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                                <h3 className="text-lg font-bold text-green-800 mb-4">优化配方结果</h3>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 text-center">
                                    <div className="p-3 bg-green-100 rounded-md">
                                        <p className="text-sm text-green-700">原料总成本</p>
                                        <p className="text-xl font-bold text-green-900">{result.totalCost.toFixed(2)} 元</p>
                                    </div>
                                    <div className="p-3 bg-yellow-100 rounded-md">
                                        <p className="text-sm text-yellow-700">原料总用量</p>
                                        <p className="text-xl font-bold text-yellow-900">{result.totalWeight.toFixed(3)} 吨</p>
                                    </div>
                                    <div className="p-3 bg-blue-100 rounded-md">
                                        <p className="text-sm text-blue-700">需填充料</p>
                                        <p className="text-xl font-bold text-blue-900">{result.fillerWeight.toFixed(3)} 吨</p>
                                    </div>
                                </div>
                                <h4 className="font-semibold text-gray-700 mt-6 mb-2">原料使用详情:</h4>
                                <ul className="divide-y divide-gray-200">
                                    {result.solution.map(item => (
                                        <li key={item.name} className="py-2 flex justify-between items-center">
                                            <span className="font-medium text-gray-800">{item.name}</span>
                                            <div className="text-right">
                                                <span className="text-gray-600">用量: <strong className="text-indigo-600">{(item.weight * 1000).toFixed(2)} 公斤</strong></span>
                                                <span className="text-gray-500 text-sm ml-4">(成本: {item.cost.toFixed(2)} 元)</span>
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        ) : (
                             <div className="p-4 bg-red-100 text-red-700 rounded-md">
                                <strong>计算失败:</strong> 无法在当前原料组合下满足所有目标元素约束。请检查目标比例是否过高，或尝试添加更多/更合适的原料。
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default OptimizerPage;
