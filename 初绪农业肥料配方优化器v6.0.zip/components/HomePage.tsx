
import React from 'react';
import { Page } from '../types';

interface HomePageProps {
    navigate: (page: Page) => void;
}

const HomePage: React.FC<HomePageProps> = ({ navigate }) => {
    return (
        <div className="flex flex-col items-center justify-center space-y-8 py-10">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-gray-800">选择一个功能</h2>
                <p className="mt-2 text-lg text-gray-600">开始您的农业计算与优化</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl">
                <FeatureCard
                    title="农药稀释计算器"
                    description="精确计算农药稀释比例，确保用药安全有效。"
                    color="blue"
                    onClick={() => navigate(Page.Pesticide)}
                />
                <FeatureCard
                    title="肥料稀释计算器"
                    description="快速计算肥料稀释配比，实现科学施肥。"
                    color="green"
                    onClick={() => navigate(Page.Fertilizer)}
                />
                <FeatureCard
                    title="肥料配方优化器"
                    description="根据目标元素和原料成本，智能生成最低成本配方。"
                    color="yellow"
                    onClick={() => navigate(Page.Optimizer)}
                />
            </div>
        </div>
    );
};

interface FeatureCardProps {
    title: string;
    description: string;
    color: 'blue' | 'green' | 'yellow';
    onClick: () => void;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ title, description, color, onClick }) => {
    const colorClasses = {
        blue: {
            bg: 'bg-blue-500',
            hoverBg: 'bg-blue-600',
            text: 'text-blue-800',
            border: 'border-blue-500'
        },
        green: {
            bg: 'bg-green-500',
            hoverBg: 'bg-green-600',
            text: 'text-green-800',
            border: 'border-green-500'
        },
        yellow: {
            bg: 'bg-yellow-400',
            hoverBg: 'bg-yellow-500',
            text: 'text-yellow-800',
            border: 'border-yellow-400'
        },
    };

    const selectedColor = colorClasses[color];

    return (
        <div
            onClick={onClick}
            className="group cursor-pointer rounded-xl bg-white p-6 shadow-lg hover:shadow-2xl transition-shadow duration-300 border-t-4"
            style={{ borderTopColor: selectedColor.border.replace('border-', '#') }}
        >
            <h3 className={`text-2xl font-bold ${selectedColor.text}`}>{title}</h3>
            <p className="mt-4 text-gray-600">{description}</p>
            <button className={`mt-6 w-full text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300 ${selectedColor.bg} ${selectedColor.hoverBg}`}>
                进入
            </button>
        </div>
    );
};


export default HomePage;
