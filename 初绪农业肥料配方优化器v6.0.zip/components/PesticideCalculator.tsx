
import React, { useState } from 'react';

const PesticideCalculator: React.FC = () => {
    const [originalConcentration, setOriginalConcentration] = useState('');
    const [targetConcentration, setTargetConcentration] = useState('');
    const [totalVolume, setTotalVolume] = useState('');
    const [result, setResult] = useState<string | null>(null);

    const calculate = () => {
        const C1 = parseFloat(originalConcentration);
        const C2 = parseFloat(targetConcentration);
        const V2 = parseFloat(totalVolume);

        if (isNaN(C1) || isNaN(C2) || isNaN(V2) || C1 <= 0 || C2 <= 0 || V2 <= 0 || C1 < C2) {
            setResult('请输入有效的、大于零的数值，且原药浓度必须大于目标浓度。');
            return;
        }

        const V1 = (C2 * V2) / C1;
        setResult(`需要加入原药 ${V1.toFixed(2)} 毫升/克，并加水至 ${V2} 升/公斤。`);
    };

    const reset = () => {
        setOriginalConcentration('');
        setTargetConcentration('');
        setTotalVolume('');
        setResult(null);
    };

    return (
        <div className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-md border-t-4 border-blue-500">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">农药稀释计算器</h2>
            <div className="space-y-4">
                <InputField label="原药浓度 (%)" value={originalConcentration} onChange={setOriginalConcentration} placeholder="例如: 40" />
                <InputField label="目标浓度 (%)" value={targetConcentration} onChange={setTargetConcentration} placeholder="例如: 0.02" />
                <InputField label="用水总量 (升/公斤)" value={totalVolume} onChange={setTotalVolume} placeholder="例如: 15" />
            </div>
            <div className="mt-6 flex space-x-4">
                <button onClick={calculate} className="w-full bg-blue-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors">计算</button>
                <button onClick={reset} className="w-full bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors">重置</button>
            </div>
            {result && (
                <div className={`mt-6 p-4 rounded-lg ${result.includes('有效') ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'}`}>
                    <p className="font-semibold">{result}</p>
                </div>
            )}
        </div>
    );
};

interface InputFieldProps {
    label: string;
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
}

const InputField: React.FC<InputFieldProps> = ({ label, value, onChange, placeholder }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <input
            type="number"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
        />
    </div>
);

export default PesticideCalculator;
