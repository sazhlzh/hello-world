
import React, { useState } from 'react';

const FertilizerCalculator: React.FC = () => {
    const [dilutionFactor, setDilutionFactor] = useState('');
    const [totalVolume, setTotalVolume] = useState('');
    const [result, setResult] = useState<string | null>(null);

    const calculate = () => {
        const factor = parseFloat(dilutionFactor);
        const volume = parseFloat(totalVolume);

        if (isNaN(factor) || isNaN(volume) || factor <= 0 || volume <= 0) {
            setResult('请输入有效的、大于零的数值。');
            return;
        }

        const fertilizerAmount = (volume * 1000) / factor; // volume in L to mL or kg to g
        setResult(`对于 ${volume} 升/公斤 的水，需要加入肥料 ${fertilizerAmount.toFixed(2)} 克/毫升。`);
    };
    
    const reset = () => {
        setDilutionFactor('');
        setTotalVolume('');
        setResult(null);
    };

    return (
        <div className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-md border-t-4 border-green-500">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">肥料稀释计算器</h2>
            <div className="space-y-4">
                <InputField label="稀释倍数 (倍)" value={dilutionFactor} onChange={setDilutionFactor} placeholder="例如: 800" />
                <InputField label="计划施用水量 (升/公斤)" value={totalVolume} onChange={setTotalVolume} placeholder="例如: 30" />
            </div>
            <div className="mt-6 flex space-x-4">
                <button onClick={calculate} className="w-full bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-600 transition-colors">计算</button>
                <button onClick={reset} className="w-full bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors">重置</button>
            </div>
            {result && (
                <div className={`mt-6 p-4 rounded-lg ${result.includes('有效') ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                    <p className="font-semibold">{result}</p>
                </div>
            )}
        </div>
    );
};

interface InputFieldProps {
    label: string;
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
}

const InputField: React.FC<InputFieldProps> = ({ label, value, onChange, placeholder }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <input
            type="number"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
        />
    </div>
);

export default FertilizerCalculator;
