
import { TargetElement, RawMaterial } from './types';

export const DEFAULT_TARGET_ELEMENTS: Omit<TargetElement, 'id'>[] = [
    { name: '氮(N)', percentage: '15' },
    { name: '磷(P)', percentage: '15' },
    { name: '钾(K)', percentage: '15' },
    { name: '钙(Ca)', percentage: '0.1' },
    { name: '镁(Mg)', percentage: '0' },
    { name: '硼(B)', percentage: '0' },
    { name: '锌(Zn)', percentage: '0' },
    { name: '铁(Fe)', percentage: '0' },
];

export const DEFAULT_RAW_MATERIALS: Omit<RawMaterial, 'id' | 'price'>[] = [
    { name: '尿素', elements: { '氮(N)': '46' } },
    { name: '磷酸一铵', elements: { '氮(N)': '11', '磷(P)': '44' } },
    { name: '磷酸二铵', elements: { '氮(N)': '18', '磷(P)': '46' } },
    { name: '硫酸钾', elements: { '钾(K)': '50' } },
    { name: '氯化钾', elements: { '钾(K)': '60' } },
    { name: '硝酸钾', elements: { '氮(N)': '13.5', '钾(K)': '45' } },
    { name: '硝酸铵钙', elements: { '氮(N)': '15.5', '钙(Ca)': '19' } },
    { name: '硫酸铵', elements: { '氮(N)': '21' } },
    { name: '过磷酸钙', elements: { '磷(P)': '12', '钙(Ca)': '20' } },
    { name: '重过磷酸钙', elements: { '磷(P)': '44', '钙(Ca)': '14' } },
    { name: '硫酸镁', elements: { '镁(Mg)': '9.6' } },
    { name: 'EDTA-钙', elements: { '钙(Ca)': '10' } },
    { name: 'EDTA-镁', elements: { '镁(Mg)': '6' } },
    { name: 'EDTA-锌', elements: { '锌(Zn)': '15' } },
    { name: 'EDTA-铁', elements: { '铁(Fe)': '13' } },
    { name: '硼砂', elements: { '硼(B)': '11' } },
];
