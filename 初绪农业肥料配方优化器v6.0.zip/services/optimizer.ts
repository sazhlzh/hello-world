
import { TargetElement, RawMaterial, OptimizationResult } from '../types';

declare const solver: any; // Declare the global solver object from the script

interface ParsedTargetElement {
    id: number;
    name: string;
    percentage: number;
}

interface ParsedRawMaterial {
    id: number;
    name: string;
    elements: { [key: string]: number };
    price: number;
}

export const solveOptimization = (
    totalProduction: number, // in tons
    targetElements: ParsedTargetElement[],
    rawMaterials: ParsedRawMaterial[]
): OptimizationResult => {

    const model = {
        optimize: "cost",
        opType: "min",
        constraints: {},
        variables: {},
        ints: {} // Not using integer programming for this
    };

    // Set up constraints from target elements
    targetElements.forEach(el => {
        if (el.percentage > 0) {
            // Target amount in kg. totalProduction is in tons. percentage is in %.
            // (totalProduction tons) * (el.percentage / 100) * 1000 kg/ton
            const targetAmountKg = totalProduction * el.percentage * 10;
            model.constraints[el.name] = { min: targetAmountKg };
        }
    });

    // Set up variables from raw materials
    rawMaterials.forEach(mat => {
        if (mat.price > 0 && mat.name) {
            const variable = {
                cost: mat.price // Cost per ton
            };
            targetElements.forEach(el => {
                const content = mat.elements[el.name] || 0;
                if (content > 0) {
                    // Content in kg per ton of material.
                    // (content / 100) * 1000 kg/ton
                    variable[el.name] = content * 10;
                }
            });
            model.variables[mat.name] = variable;
        }
    });

    const result = solver.Solve(model);

    if (!result.feasible) {
        return {
            feasible: false,
            totalCost: 0,
            totalWeight: 0,
            fillerWeight: 0,
            solution: []
        };
    }

    let totalWeight = 0;
    const solutionDetails = [];

    for (const materialName in result) {
        if (materialName === 'feasible' || materialName === 'result') continue;
        
        const weightInTons = result[materialName];
        if (weightInTons > 0.00001) { // Filter out negligible amounts
            const materialInfo = rawMaterials.find(m => m.name === materialName);
            if (materialInfo) {
                totalWeight += weightInTons;
                const cost = weightInTons * materialInfo.price;
                
                // A simple heuristic to classify as "trace" element source
                const isTraceSource = !['氮(N)', '磷(P)', '钾(K)'].some(mainEl => (materialInfo.elements[mainEl] || 0) > 5);

                solutionDetails.push({
                    name: materialName,
                    weight: weightInTons, // in tons
                    cost: cost,
                    isTrace: isTraceSource
                });
            }
        }
    }

    const totalCost = solutionDetails.reduce((acc, item) => acc + item.cost, 0);
    const fillerWeight = totalProduction - totalWeight;

    return {
        feasible: true,
        totalCost: totalCost,
        totalWeight: totalWeight,
        fillerWeight: fillerWeight > 0 ? fillerWeight : 0,
        solution: solutionDetails.sort((a,b) => b.weight - a.weight) // Sort by weight descending
    };
};
