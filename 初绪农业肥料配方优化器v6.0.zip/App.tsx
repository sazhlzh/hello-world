
import React, { useState } from 'react';
import { Page } from './types';
import HomePage from './components/HomePage';
import PesticideCalculator from './components/PesticideCalculator';
import FertilizerCalculator from './components/FertilizerCalculator';
import OptimizerPage from './components/OptimizerPage';
import { ArrowLeftIcon } from './components/Icons';

const App: React.FC = () => {
    const [currentPage, setCurrentPage] = useState<Page>(Page.Home);

    const renderPage = () => {
        switch (currentPage) {
            case Page.Pesticide:
                return <PesticideCalculator />;
            case Page.Fertilizer:
                return <FertilizerCalculator />;
            case Page.Optimizer:
                return <OptimizerPage />;
            case Page.Home:
            default:
                return <HomePage navigate={setCurrentPage} />;
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 text-gray-800 antialiased">
            <header className="bg-white shadow-md">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-20">
                        <div className="flex items-center space-x-4">
                             {currentPage !== Page.Home && (
                                <button
                                    onClick={() => setCurrentPage(Page.Home)}
                                    className="p-2 rounded-full text-gray-600 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                                    aria-label="返回主菜单"
                                >
                                    <ArrowLeftIcon className="h-6 w-6" />
                                </button>
                            )}
                            <div className="flex items-center space-x-2">
                                <span className="text-xl font-bold text-green-700">初绪农业</span>
                                <h1 className="text-xl sm:text-2xl font-semibold text-gray-700">
                                    肥料配方优化器v6.0
                                </h1>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            
            <main className="container mx-auto p-4 sm:p-6 lg:p-8">
                {renderPage()}
            </main>

            <footer className="text-center py-6 text-sm text-gray-500">
                <p>青岛初绪农业科技有限公司出品</p>
            </footer>
        </div>
    );
};

export default App;
