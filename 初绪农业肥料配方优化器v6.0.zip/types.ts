
export enum Page {
    Home,
    Pesticide,
    Fertilizer,
    Optimizer
}

export interface TargetElement {
    id: number;
    name: string;
    percentage: string;
}

export interface RawMaterial {
    id: number;
    name: string;
    elements: { [key: string]: string };
    price: string;
}

export interface OptimizationResult {
    feasible: boolean;
    totalCost: number;
    totalWeight: number;
    fillerWeight: number;
    solution: {
        name: string;
        weight: number;
        cost: number;
        isTrace: boolean;
    }[];
}
